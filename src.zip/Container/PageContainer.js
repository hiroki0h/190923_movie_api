import React, { Component } from 'react';
import { moviesApi } from '../Api';
import { connect } from 'react-redux';
import ListTheme from '../assets/ListTheme';
import Loader from '../components/Loader';
import List from '../components/List';
import PaginationContainer from './PaginationContainer';

class PageContainer extends Component { 
  state = {
    isLoading : false,
    totalPages : 0,
    moviesResult : []
  }
  getPageMovies = async (current, pagename) => { 
    const { data: { results : moviesResult, total_pages: pageLength } } 
    = await moviesApi.movieList(current, pagename);
    this.setState({
      isLoading : true,
      totalPages : pageLength,
      moviesResult : [...moviesResult]
    });
  }
  // 처음 로딩 되었을때!!!!
  componentDidMount(){
    this.getPageMovies(this.props.current, this.props.pagename);
  }
  // 업데이트 되었을때!!!
  componentDidUpdate(prevProps, prevState) {
    // 다른 페이지에서 새로고침을 하면 초기state home으로 들어간다
    if(prevProps !== 'home'){
      this.getPageMovies(this.props.current, this.props.pagename);
    }
  }
  render(){
    const { isLoading, moviesResult, totalPages } = this.state;
    const { pagename, current, match } = this.props;
    const category = match.url.split('/')[1];
    console.log('category - '+category);
    console.log('pagename - '+this.props.pagename);
    return(
      <>
        <ListTheme/>
        {!isLoading
          ? <Loader/>
          :<>
              <List
                pagename={pagename}
                moviesResult={moviesResult}
              />
              <PaginationContainer
                totalPages={totalPages}
                current={current}
                category={category}
              />
            </>
        }
      </>
    )
  }
}
const mapStateToProps = ({ INIT }) => ({
  pagename : INIT.pagename,
  current : INIT.current
});
const mapDispatchToProps = { };
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(PageContainer);